import React from "react";

export default function VishnuPortfolio() {
  return (
    <div className="min-h-screen bg-gray-100 text-gray-800 p-6">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold mb-2">Namaste, I'm Vishnu Solanki</h1>
        <p className="text-lg">Fullstack Developer | MERN Stack | PHP | Laravel</p>
        <div className="mt-4 flex justify-center gap-4">
          <a href="mailto:vishnu1810@hotmail.com" className="bg-blue-500 text-white px-4 py-2 rounded">
            Email Me
          </a>
          <a href="https://github.com/Vishnusolanki" target="_blank" rel="noopener noreferrer" className="bg-gray-800 text-white px-4 py-2 rounded">
            GitHub
          </a>
        </div>
      </header>

      <section className="mb-10">
        <h2 className="text-2xl font-semibold mb-4">About Me</h2>
        <p>
          I'm a Fullstack Developer based in Vadodara, Gujarat with experience in MERN Stack and Laravel. I enjoy
          building web applications that are fast, responsive, and user-friendly.
        </p>
      </section>

      <section className="mb-10">
        <h2 className="text-2xl font-semibold mb-4">Experience</h2>
        <ul className="space-y-4">
          <li>
            <strong>Limbani Softwares</strong> – MERN Stack Developer (Nov 2022 - May 2024)
            <ul>
              <li>Created REST APIs using Node.js & Express</li>
              <li>Structured MongoDB databases using Mongoose</li>
              <li>Focused on backend development and testing</li>
            </ul>
          </li>
          <li>
            <strong>Legacy Digitronics Pvt. Ltd</strong> – Backend Developer (Jan 2022 - Sep 2022)
            <ul>
              <li>Built PHP-based web apps and resolved bugs</li>
              <li>Handled full-stack features and testing</li>
            </ul>
          </li>
          <li>
            <strong>Pramarth Softtech</strong> – Laravel Developer (Freelance, Jan 2021 - Dec 2021)
            <ul>
              <li>Developed apps using Laravel</li>
              <li>Handled troubleshooting and testing</li>
            </ul>
          </li>
          <li>
            <strong>Ragns Job Portal</strong> – Data Entry Assistant (Mar 2021 - Jan 2022)
            <ul>
              <li>Handled resume sourcing and basic data entry</li>
            </ul>
          </li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Skills</h2>
        <ul>
          <li>Languages: HTML, CSS, JavaScript, PHP</li>
          <li>Frameworks: React.js, Express.js, Laravel</li>
          <li>Databases: MongoDB, MySQL</li>
          <li>Version Control: Git, GitHub</li>
        </ul>
      </section>
    </div>
  );
}
